# Arduino Basic Hello World

This example simply compiles in wolfSSL and shows the current version number.

NOTE: Moving; See https://github.com/wolfSSL/wolfssl-examples/pull/499
